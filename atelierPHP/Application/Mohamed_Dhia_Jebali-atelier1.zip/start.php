<?php
include 'Club.php';
$club=new Club(1,'Club Robotique','Test','Esprit Ghazala','Electromecanique');
$club->afficherClub();
?>